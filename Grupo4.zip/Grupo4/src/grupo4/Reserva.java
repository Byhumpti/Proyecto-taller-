package grupo4;


public class Reserva {
    private final Usuario usuario;
    private final Habitacion habitacion;
    private final int noches;

    public Reserva(Usuario usuario, Habitacion habitacion, int noches) {
        this.usuario = usuario;
        this.habitacion = habitacion;
        this.noches = noches;
        habitacion.setDisponible(false); // Ocupamos la habitación al reservar
    }

    public void mostrarInfo() {
        System.out.println("----- RESERVA -----");
        usuario.mostrarInfo();
        habitacion.mostrarInfo();
        System.out.println("Noches: " + noches);
        System.out.println("Total a pagar: S/ " + calcularTotal());
        System.out.println("-------------------");
    }

    public double calcularTotal() {
        return habitacion.getPrecio() * noches;
    }

    // Getters
    public Usuario getUsuario() {
        return usuario;
    }

    public Habitacion getHabitacion() {
        return habitacion;
    }

    public int getNoches() {
        return noches;
    }
}
