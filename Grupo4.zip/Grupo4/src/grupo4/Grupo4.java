import grupo4.Habitacion;
import grupo4.Usuario;
import grupo4.Reserva;

import java.util.ArrayList;
import java.util.Scanner;


public class Grupo4 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            //Lista de habitaciones
            ArrayList<Habitacion> habitaciones = new ArrayList<>();
            //lista de reservas activas
            ArrayList<Reserva> reservas = new ArrayList<>();
            
            // Habitaciones predeterminadas
            habitaciones.add(new Habitacion(1, "Simple", 80.0));
            habitaciones.add(new Habitacion(2, "Doble", 150.0));
            habitaciones.add(new Habitacion(3, "Simple", 90.0));
            habitaciones.add(new Habitacion(4, "Doble", 160.0));
            
            int opcion;
            //bucle del menu
            do {
                System.out.println("\n==== MENÚ PRINCIPAL ====");
                System.out.println("1. Ver habitaciones disponibles");
                System.out.println("2. Realizar reserva");
                System.out.println("3. Ver reservas realizadas");
                System.out.println("4. Cancelar reserva");
                System.out.println("5. Salir");
                System.out.print("Seleccione una opción: ");
                opcion = sc.nextInt();
                sc.nextLine(); // Limpia el bufer
                
                switch (opcion) {
                    case 1 -> {
                        //Muestra las habitaciones 
                        System.out.println("\n=== HABITACIONES DISPONIBLES ===");
                        for (Habitacion h : habitaciones) {
                            if (h.isDisponible()) {
                                h.mostrarInfo();
                            }
                        }
                    }
                        
                    case 2 -> {
                        // Registrar usuario
                        System.out.print("Ingrese nombre del usuario: ");
                        String nombre = sc.nextLine();
                        System.out.print("Ingrese DNI del usuario: ");
                        String dni = sc.nextLine();
                        Usuario usuario = new Usuario(nombre, dni);

                        // Mostrar habitaciones disponibles
                        System.out.println("Habitaciones disponibles:");
                        for (Habitacion h : habitaciones) {
                            if (h.isDisponible()) {
                                System.out.println("ID: " + h.getId() + " - Tipo: " + h.getTipo() + " - Precio: S/ " + h.getPrecio());
                            }
                        }

                        // Seleccion de habitacion
                        System.out.print("Ingrese ID de la habitacion a reservar: ");
                        int idHab = sc.nextInt();
                        System.out.print("Ingrese numero de noches: ");
                        int noches = sc.nextInt();
                        sc.nextLine(); // Limpia el buffer

                        // Buscar habitacion
                        Habitacion habitacionSeleccionada = null;
                        for (Habitacion h : habitaciones) {
                            if (h.getId() == idHab && h.isDisponible()) {
                                habitacionSeleccionada = h;
                                break;
                            }
                        }

                        if (habitacionSeleccionada != null) {
                            Reserva nuevaReserva = new Reserva(usuario, habitacionSeleccionada, noches);
                            reservas.add(nuevaReserva);
                            habitacionSeleccionada.setDisponible(false);

                            // Marcar como no disponible
                            habitacionSeleccionada.setDisponible(false);

                            System.out.println("Reserva realizada.");
                            nuevaReserva.mostrarInfo();
                        } else {
                            System.out.println("ID inválido o habitación no disponible.");
                        }
                    }

                    case 3 -> {
                        // Mostrar reservas activas
                        System.out.println("\n=== RESERVAS REALIZADAS ===");
                        if (reservas.isEmpty()) {
                            System.out.println("No hay reservas.");
                        } else {
                            for (Reserva r : reservas) {
                                r.mostrarInfo();
                            }
                        }
                    }

                    case 4-> {
                    // Cancelar reserva
                        System.out.print("Ingrese DNI para buscar sus reservas: ");
                        String dniBuscar = sc.nextLine();

                        ArrayList<Reserva> reservasUsuario = new ArrayList<>();
                        for (Reserva r : reservas) {
                            if (r.getUsuario().getDni().equals(dniBuscar)) {
                                reservasUsuario.add(r);
                            }
                        }

                        if (reservasUsuario.isEmpty()) {
                            System.out.println("No se encontraron reservas con ese DNI.");
                        } else {
                            System.out.println("Reservas encontradas:");
                            for (int i = 0; i < reservasUsuario.size(); i++) {
                                System.out.print((i + 1) + ". ");
                                reservasUsuario.get(i).mostrarInfo();
                            }

                            System.out.print("Seleccione el numero de reserva a cancelar: ");
                            int seleccion = sc.nextInt();
                            sc.nextLine();

                            if (seleccion >= 1 && seleccion <= reservasUsuario.size()) {
                                Reserva reservaACancelar = reservasUsuario.get(seleccion - 1);
                                reservaACancelar.getHabitacion().setDisponible(true);
                                reservas.remove(reservaACancelar);
                                System.out.println(" Reserva cancelada correctamente.");
                            } else {
                                System.out.println(" Seleccion invalida.");
                            }
                        }
                    }

                    case 5 -> System.out.println("Saliendo del sistema...");

                    default -> System.out.println(" Opcion invalida. Intente de nuevo.");
                }

            } while (opcion != 5);
        }
    }
}