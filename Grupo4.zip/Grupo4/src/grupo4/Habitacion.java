package grupo4;


public class Habitacion {
    private final int id;
    private final String tipo; // simple, doble, etc.
    private final double precio;
    private boolean disponible;

    public Habitacion(int id, String tipo, double precio) {
        this.id = id;
        this.tipo = tipo;
        this.precio = precio;
        this.disponible = true; // disponible por defecto
    }

    public void mostrarInfo() {
        System.out.println("ID: " + id);
        System.out.println("Tipo: " + tipo);
        System.out.println("Precio por noche: S/ " + precio);
        System.out.println("Disponible: " + (disponible ? "Sí" : "No"));
        System.out.println("-----------------------------");
    }

    // Getters y setters
    public int getId() {
        return id;
    }

    public String getTipo() {
        return tipo;
    }

    public double getPrecio() {
        return precio;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }
}
